% 0 nocasa
% 1 nofora
% 2 norepes
% 3 nopartit
% 4 sipartit
% Aquest ha de ser el primer valor, la resta de valors van en el mateix ordre que el fitxer original

0,6,5
0,5,2
0,4,9
1,4,3
1,2,1
2,1,2
2,12,13
3,1,6,1
3,5,2,1
4,6,3,3
4,4,5,5

